var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./JosephM.Xrm.Pcf.FormMessage/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./JosephM.Xrm.Pcf.FormMessage/index.ts":
/*!**********************************************!*\
  !*** ./JosephM.Xrm.Pcf.FormMessage/index.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.FormMessage = void 0;\n\nvar FormMessage = function () {\n  function FormMessage() {}\n\n  FormMessage.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._paragraph = document.createElement(\"p\");\n    this._container = document.createElement(\"div\");\n\n    this._container.appendChild(this._paragraph);\n\n    container.appendChild(this._container);\n  };\n\n  FormMessage.prototype.updateView = function (context) {\n    this._value = context.parameters.controlValue.raw;\n    var backgroundColourPart = \"\";\n\n    if (context.parameters.backgroundColourValue.raw != null) {\n      backgroundColourPart = \"background-color: \" + context.parameters.backgroundColourValue.raw + \"; \";\n    }\n\n    var fontColourPart = \"\";\n\n    if (context.parameters.fontColourValue.raw != null) {\n      fontColourPart = \"color: \" + context.parameters.fontColourValue.raw + \"; \";\n    }\n\n    var html = \"    <div style='padding: 5px; display: table; text-align: center;  width: 100%; overflow: hidden; \" + backgroundColourPart + \"padding-right: 10px'>\";\n    html += \"        <div style='display: table-cell; vertical-align: middle;'>\";\n    html += \"            <div id='message' style='min-height: 25px; font-weight: bold; \" + fontColourPart + \"vertical-align: middle' >\" + this._value + \"</div>\";\n    html += \"        </div>\";\n    html += \"    </div>\";\n    this._paragraph.innerHTML = html;\n  };\n\n  FormMessage.prototype.getOutputs = function () {\n    var result = {\n      controlValue: this._value\n    };\n    return result;\n  };\n\n  FormMessage.prototype.destroy = function () {};\n\n  return FormMessage;\n}();\n\nexports.FormMessage = FormMessage;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./JosephM.Xrm.Pcf.FormMessage/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('JosephM.Xrm.Pcf.FormMessage', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FormMessage);
} else {
	var JosephM = JosephM || {};
	JosephM.Xrm = JosephM.Xrm || {};
	JosephM.Xrm.Pcf = JosephM.Xrm.Pcf || {};
	JosephM.Xrm.Pcf.FormMessage = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FormMessage;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}